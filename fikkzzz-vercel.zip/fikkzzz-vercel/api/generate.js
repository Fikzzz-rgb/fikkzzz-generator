export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { image, image_type, person_count } = req.body;
  if (!image) return res.status(400).json({ error: 'Tidak ada gambar' });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'API key belum diset di Vercel Environment Variables' });

  const isTwoPeople = person_count === 2;

  const systemPrompt = `You are an elite AI prompt engineer specialized in generating hyper-realistic photography prompts for AI image generators like Midjourney, DALL-E, Stable Diffusion, and Flux. Your job is to analyze every single pixel of a photo and extract maximum detail to craft a prompt so precise that the generated image looks like a real photograph — indistinguishable from reality.

CRITICAL RULES:
1. The subject's FACE must be described as "use subject's real face, realistic face, photographic face, not AI-generated face, authentic facial features"
2. Everything EXCEPT the face follows the image exactly
3. Output ONLY the final prompt — no explanation, no markdown, no headers
4. Write in English
5. The prompt must be ultra-detailed

MANDATORY DETAILS TO EXTRACT AND DESCRIBE:
- Full body pose (standing/sitting/leaning/crouching, exact posture, weight distribution)
- Direction the subject is facing (camera angle, head tilt, eye contact or not)
- Facial expression (smile type, teeth visible or not, eyebrow position, eye shape, eye direction)
- Hand pose and gesture (exact finger positions, hand placement on body or object)
- Lip position (open/closed/slightly parted, teeth showing, lip shape)
- Top clothing: brand visible?, shirt/jacket/hoodie/polo type, exact fit (oversized/slim/regular/boxy), cut style, collar style, sleeve length, fabric texture, color, any graphics/logos/prints + exact position on garment (chest left, chest right, center, back, sleeve)
- Bottom clothing: pants/shorts/skirt type, fit (baggy/skinny/regular/wide-leg/straight), waistline height, length, fabric texture, color, any distressing or details
- Footwear: shoe brand if visible, shoe type, color, condition
- Accessories: watch, rings, necklaces, earrings, cap/hat, bag, sunglasses — describe each in detail
- Background environment: indoor/outdoor, specific location type
- Geographic context: tropical, urban, rural, coastal, mountain, city skyline
- People or activity in background: busy crowd, empty, few people, cars passing, vendors
- Weather conditions: sunny, overcast, golden hour, rainy, foggy, humid tropical
- Sky and clouds: clear blue, dramatic clouds, sunset colors, overcast grey
- Sunlight direction and quality: harsh midday, soft morning side light, warm backlit golden hour
- Wind effect: hair movement, fabric movement direction
- Food or objects on table if visible
- Smoke, steam, dust particles if any
- Subject's current activity
- Camera style: iPhone 14 Pro ProRAW quality, 26mm main lens, natural shallow bokeh, true-to-life color, no heavy filter, photojournalism realism, sharp subject, real skin texture, pores visible
- Any special visual effects from original photo: lens flare, motion blur, vignette
${isTwoPeople ? `- ADDITIONAL FOR 2 PEOPLE: Add a realistic attractive young Indonesian woman naturally beside the male subject. Describe her exact position, her pose complementing his, clothing style matching the scene, her expression. They look like a real couple in a candid or semi-posed photo.` : ''}

PROMPT FORMAT: Write as a continuous, comma-separated description starting with shot type and camera. Aim for 400-600 words. Make it feel like a real photographer's brief.`;

  const userMessage = isTwoPeople
    ? "Analyze this photo in extreme detail and generate a hyper-realistic photography prompt. The male subject's face must remain authentic/real — write 'subject authentic real face, photorealistic facial features, not AI face'. Add a natural female companion beside him. Capture every detail — clothing, pose, expression, environment, lighting, weather, camera characteristics."
    : "Analyze this photo in extreme detail and generate a hyper-realistic photography prompt. The subject's face must be authentic/real — write 'subject authentic real face, photorealistic facial features, not AI face'. Capture every single detail — clothing (model, fit, cut, logo placement), body pose, facial expression, lip position, hand gesture, background activity, weather, clouds, sunlight, wind, objects nearby, camera lens characteristics. The result must look like a real iPhone 14 Pro photograph.";

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: image_type || 'image/jpeg',
                data: image
              }
            },
            { type: 'text', text: userMessage }
          ]
        }]
      })
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || `Anthropic API error ${response.status}`);
    }

    const data = await response.json();
    const text = data.content?.map(b => b.text || '').join('') || '';
    if (!text.trim()) throw new Error('Prompt kosong dari AI');

    return res.status(200).json({ prompt: text.trim() });

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
